//
//  GetFoodData.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//

import Foundation

class GetFoodData {
    
    func getName(foodName: String) -> Array<String>{
        let searchName = foodName.replacingOccurrences(of: " ", with: "+", options: .literal, range: nil)
        var foodArray = [String]()
        
        for i in 1...5{
            let urlString = "https://www.mynetdiary.com/openCatalogFindFoods.do?beanInputString=\(searchName)&detailsExpected=true&pageNumber=\(i)&pageSize=1&highlightedTermClassName=sughtrm&findContributed=true"
            
            let request = NSURL(string: urlString)
            
            let data = NSData(contentsOf: request! as URL)
            
            let dataString = NSString(data: data! as Data, encoding: String.Encoding.utf8.rawValue)!
            //            print(dataString)
            let bigScanner = Scanner(string: dataString as String)
            var nameString:NSString?
            
            bigScanner.scanUpTo("descForUi\":\"", into: nil)
            bigScanner.scanUpTo("\",", into: &nameString)
            if (nameString == nil) {
                foodArray.append("No Result")
            } else {
                var name = nameString!.replacingOccurrences(of: "descForUi\":\"", with: "")
                name = name.replacingOccurrences(of: "<\\/span>", with: "")
                name = name.replacingOccurrences(of: "<span class='sughtrm'>", with: "")
                foodArray.append(name)
            }
            
        }
        //        print(foodArray)
        return foodArray
    }
    
    func getCalorie(foodName: String) -> Array<String>{
        
        let searchName = foodName.replacingOccurrences(of: " ", with: "+", options: .literal, range: nil)
        var valueArray = [String]()
        
        for i in 1...5{
            let urlString = "https://www.mynetdiary.com/openCatalogFindFoods.do?beanInputString=\(searchName)&detailsExpected=true&pageNumber=\(i)&pageSize=1&highlightedTermClassName=sughtrm&findContributed=true"
            
            let request = NSURL(string: urlString)
            let data = NSData(contentsOf: request! as URL)
            
            let dataString = NSString(data: data! as Data, encoding: String.Encoding.utf8.rawValue)!
            
            let bigScanner = Scanner(string: dataString as String)
            var calString:NSString?
            
            bigScanner.scanUpTo("nutrDesc\":\"Calories\",\"nutrValue\":\"", into: nil)
            bigScanner.scanUpTo("\"}", into: &calString)
            
            if (calString == nil) {
                valueArray.append("")
            } else {
                let cals = calString!.replacingOccurrences(of: "nutrDesc\":\"Calories\",\"nutrValue\":\"", with: "")
                valueArray.append(cals)
            }
        }
        
        return valueArray
        
    }
    
}
