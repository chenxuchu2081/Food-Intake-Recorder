//
//  AddDateTVC.swift
//  Food Intake Recorder
//
//  Created by CHEN Xuchu on 18/12/2018.
//  Copyright © 2018 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreData
class AddDateTVC: UITableViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var saveData: UIBarButtonItem!
    
    var foods: FoodsMO!
    
    @IBOutlet var pickImageView : UIImageView!
    @IBOutlet var nameTF : UITextField!
    @IBOutlet var typeTF : UITextField!
    @IBOutlet var locationTF : UITextField!
    
    @IBOutlet var KcalLable : UILabel!
    @IBOutlet weak var changeSlide: UISlider!
    
    var kcalValue : Double? = 5.0
    
    @IBAction func valueChangeSlide(_ sender: UISlider){
        KcalLable.text = "\(sender.value) Kcal"
        kcalValue = Double(sender.value)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.reloadData()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        tableView.reloadData()

        //        print(dataController.listLength())
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.allowsEditing = false
                imagePicker.sourceType = .photoLibrary
                imagePicker.delegate = self
                
                present(imagePicker, animated: true, completion: nil)
            }
        }
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let Image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            pickImageView.image = Image
            pickImageView.contentMode = .scaleAspectFill
            pickImageView.clipsToBounds = true
        }
        
         dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func saveData(_ sender: Any) {
        if nameTF.text == "" || typeTF.text == "" || locationTF.text == "" {
            let alertController = UIAlertController(title: "OH MY GOD!", message: "We can't proceed because one of the fields is blank. Please fill the blank fields.", preferredStyle: .alert)
            let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            
            alertController.addAction(alertAction)
            self.present(alertController, animated: true, completion: nil)
        }
        
        print("\(String(describing: nameTF.text))")
        print("\(String(describing: typeTF.text))")
        print("\(String(describing: locationTF.text))")


        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            foods = FoodsMO(context: appDelegate.persistentContainer.viewContext)

            foods.foodName = nameTF.text
            foods.type = typeTF.text
            foods.location = locationTF.text
            foods.kcal = kcalValue!

            if let FoodImage = pickImageView.image {
                if let imageData = FoodImage.pngData() {
                    foods.foodImage = NSData(data: imageData) as Data
                }
            }
            
            print("\(String(describing: foods.foodImage))")
            print("\(String(describing: foods.foodName))")
            
            print("Saving data to DataBase ...")
            appDelegate.saveContext()
            
       

        }
         //dismiss(animated: true, completion: nil)
        tableView.reloadData()
        self.dismiss(animated: true, completion: nil);

    }
    
    
    
    
    
    
   
   /* override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 0
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 0
    }*/

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
