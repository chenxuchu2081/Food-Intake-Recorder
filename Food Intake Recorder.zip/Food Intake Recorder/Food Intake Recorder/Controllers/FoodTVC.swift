//
//  FoodTVC.swift
//  Food Intake Recorder
//
//  Created by CHEN Xuchu on 18/12/2018.
//  Copyright © 2018 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreData

class FoodTVC: UITableViewController, UISearchResultsUpdating {
    
    var foods: [FoodsMO] = []
     var searchResult:[FoodsMO] = []
    
    //search function
    var searchController:UISearchController!
    
    var adddateTVC = AddDateTVC()

    //var fetchResultController: NSFetchedResultsController<FoodsMO>!
    
    
    
//    var foodname = ["barrafina", "barrafina","barrafina","barrafina","barrafina","barrafina", "barrafina","barrafina","barrafina","barrafina"]
//    var foodimage = ["barrafina.jpg","barrafina","barrafina","barrafina","barrafina","barrafina.jpg","barrafina","barrafina","barrafina","barrafina"]
//
//    var foodlocation = ["HK","chine","HK","chine","HK","HK","chine","HK","chine","HK"]
//
//    var foodtype = ["type","type","type","type","type","type","type","type","type","type"]
//
//    var foodtime = ["time","time","time","time","time","time","time","time","time","time"]
    
    
    @IBAction func cancel(segue: UIStoryboardSegue){
        
    }
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        configureSearchSetting()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        
        if let appDelegate = (UIApplication.shared.delegate as? AppDelegate) {
            let request: NSFetchRequest<FoodsMO> = FoodsMO.fetchRequest()
            let context = appDelegate.persistentContainer.viewContext
            do{
                foods = try context.fetch(request)
                
            }catch{
                print(error)
            }
        }
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()

        
        if #available(iOS 11.0, *) {
            navigationItem.hidesSearchBarWhenScrolling = false
            tableView.reloadData()

            
            if let appDalegate = (UIApplication.shared.delegate as? AppDelegate){
                appDalegate.saveContext()
                tableView.reloadData()
            }
            
        }
        
        
    }
    
    func updateSearchResults(for searchController: UISearchController) {
        if let searchText = searchController.searchBar.text{
            SearchContent(for: searchText)
            tableView.reloadData()
        }
    }
    
    func configureSearchSetting(){
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        tableView.tableHeaderView = searchController.searchBar
        
        searchController.searchBar.tintColor = UIColor.white
        searchController.searchBar.placeholder = "Search What..."
        searchController.searchBar.barTintColor = UIColor(red: 217.0/255.0, green: 100.0/255.0, blue: 65.0/255.0, alpha: 1.0)
    }
    
    func SearchContent(for searchText: String) {
        searchResult = foods.filter({ (detail) -> Bool in
            if let name = detail.foodName, let location = detail.location {
                let isMatch = name.localizedCaseInsensitiveContains(searchText) || location.localizedCaseInsensitiveContains(searchText)
                return isMatch
            }
            
            return false
        })
    }
    
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchController.isActive{
            return searchResult.count
        }else{
        return foods.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FoodTableCell", for: indexPath) as! FoodTVCell
        
        //check searchResult or array data from coredata
        let food = (searchController.isActive) ? searchResult[indexPath.row] : foods[indexPath.row]
        
        
        
        cell.nameLabel.text = food.foodName
        cell.imageview!.image = UIImage(data: (food.foodImage as! Data))
        cell.imageview.layer.cornerRadius = 45.0
        cell.imageview.clipsToBounds = true
        
        cell.locationLabel.text = food.location
        cell.typeLabel.text = food.type
        //cell.timeLabel.text = foodtime[indexPath.row]
        // Configure the cell...

        return cell
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let shareAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Share", handler: { (action, indexPath) -> Void in
            
            let defaultText = "Just checking in at " + self.foods[indexPath.row].foodName!
            
            if let imageToShare = UIImage(data: self.foods[indexPath.row].foodImage as! Data) {
                let activityController = UIActivityViewController(activityItems: [defaultText, imageToShare], applicationActivities: nil)
                self.present(activityController, animated: true, completion: nil)
            }
        })
        
        // Delete button
        let deleteAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Delete",handler: { (action, indexPath) -> Void in
            
            if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
                let context = appDelegate.persistentContainer.viewContext
                let foodToDelete = self.foods.remove(at: indexPath.row)
                context.delete(foodToDelete)
                
                appDelegate.saveContext()
            }
            // Delete the row from the data source
           // self.foods.remove(at: indexPath.row)
        
            
            self.tableView.deleteRows(at: [indexPath], with: .fade)
        })
        
     
        
        shareAction.backgroundColor = UIColor(red: 49.0/255.0, green: 170.0/255.0, blue: 95.0/255.0, alpha: 1.0)
        deleteAction.backgroundColor = UIColor(red: 180.0/255.0, green: 180.0/255.0, blue: 180.0/255.0, alpha: 1.0)
        
        return [deleteAction, shareAction]
    }

    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        
        // it can not delete or share when searching
        if searchController.isActive{
            return false
        }else{
        return true
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "DisplayDetail"{
            if let DetailFood = segue.destination as? FoodDetailViewController{
                if let indexPath = self.tableView.indexPathForSelectedRow{
                    DetailFood.food = (searchController.isActive) ? searchResult[indexPath.row] : foods[indexPath.row]
                }
                
                
            }
        }
     
}
    
    

    
    // Override to support editing the table view.
//    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
//        if editingStyle == .delete {
//            // Delete the row from the data source
//            foods.remove(at: indexPath.row)
//            tableView.deleteRows(at: [indexPath], with: .fade)
//        } else if editingStyle == .insert {
//            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
//        }
//    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func viewDidAppear(_ animated: Bool) {
        
        let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn");
        
        if(!isUserLoggedIn){
            
            self.performSegue(withIdentifier: "loginView",sender: self);
        }
    }

}
