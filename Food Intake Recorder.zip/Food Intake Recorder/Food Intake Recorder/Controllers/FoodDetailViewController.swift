//
//  FoodDetailViewController.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 22/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//

import UIKit

class FoodDetailViewController: UIViewController {

    var food : FoodsMO?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
 
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var typeLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var Image: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if let foodLabel = food {
            self.nameLabel.text = foodLabel.foodName
            self.typeLabel.text = foodLabel.type
            self.locationLabel.text = foodLabel.location
            self.Image.image = UIImage(data: (foodLabel.foodImage as! Data))
        }
        
      
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
