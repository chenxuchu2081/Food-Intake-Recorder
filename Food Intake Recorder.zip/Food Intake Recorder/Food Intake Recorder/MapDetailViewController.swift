//
//  MapDetailViewController.swift
//  Food Intake Recorder
//
//  Created by CHEN Xuchu on 29/12/2018.
//  Copyright © 2018 CHEN Xuchu. All rights reserved.
//

import UIKit
import MapKit

class MapDetailViewController: UIViewController, MKMapViewDelegate {
    
    
    var locationLatitude : Double!
    var locationLongitude : Double!
    var locationTitle : String!
    @IBOutlet weak var mapView : MKMapView?
    var annotations = [MKPointAnnotation]();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView?.delegate = self
        // Do any additional setup after loading the view.
        showMap()
    }
    
    @objc func showMap(){
        
        if locationLatitude != nil && locationLongitude != nil && locationTitle != nil{
            
            let nycAnnotation = MKPointAnnotation();
            nycAnnotation.coordinate = CLLocationCoordinate2D(latitude: locationLatitude, longitude: locationLongitude);
            nycAnnotation.title = locationTitle;
            self.annotations.append(nycAnnotation);
            //Do the rest cities here
            
            self.mapView?.addAnnotations(self.annotations);
            
            
            let overlayCoords = [
                CLLocationCoordinate2D(latitude: locationLatitude, longitude: locationLongitude),
                
                ]
            let overlay = MKPolygon(coordinates: overlayCoords, count: 1);
            let span = MKCoordinateSpan(latitudeDelta: 0.6, longitudeDelta: 0.6);
            let coord = CLLocationCoordinate2D(latitude: locationLatitude!, longitude: locationLongitude!);
            let region = MKCoordinateRegion(center: coord, span: span)
            self.mapView?.delegate = self;
            self.mapView?.setRegion(region, animated: false);
            self.mapView?.addOverlay(overlay);
        }
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
