//
//  AddFoodViewController.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//

import UIKit
import CoreData
import MapKit
class AddFoodViewController: UIViewController, UITextFieldDelegate, UIApplicationDelegate,MKMapViewDelegate {
    
    @IBOutlet var foodName : UITextField!
    @IBOutlet var date : UITextField!
    @IBOutlet var calorie : UITextField!
    @IBOutlet var searchBtn : UIButton!
    @IBOutlet var remark : UITextField!
    @IBOutlet var radio : UIButton!
    @IBOutlet weak var foodPhoto : UIImageView!
    
    @IBOutlet var name1 : UILabel!
    @IBOutlet var name2 : UILabel!
    @IBOutlet var name3 : UILabel!
    @IBOutlet var name4 : UILabel!
    @IBOutlet var name5 : UILabel!
    
    @IBOutlet var cal1 : UILabel!
    @IBOutlet var cal2 : UILabel!
    @IBOutlet var cal3 : UILabel!
    @IBOutlet var cal4 : UILabel!
    @IBOutlet var cal5 : UILabel!
    
    var haverecord = 0
    var audiopath = ""
    @IBOutlet weak var locationTF : UITextField!
    
    var locationLatitude : Double?
    var locationLongitude : Double?
    var locationTitle : String?
    
    let dateFormatter = DateFormatter()
    
    @IBOutlet weak var mapView : MKMapView?
    var annotations = [MKPointAnnotation]();
    
    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    
    var theRecord : Record?;
    
    var foodArray = [String]()
    var valueArray = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        foodPhoto.isUserInteractionEnabled = true
        self.foodName.delegate = self
        self.calorie.delegate = self
        self.calorie.keyboardType = .numberPad
        self.remark.delegate = self
        mapView?.delegate = self
        dateFormatter.dateFormat="d MMM yyyy"
        date.text = dateFormatter.string(from: Date())
        touchMapGoPage()
        showMap()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //for edit
        dateTextFieldEditing(sender: date)
        if let record = theRecord {
            self.foodName.text = record.foodname!
            self.calorie.text = record.calorie!
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //map
    @objc func showMaps() {
        self.performSegue(withIdentifier: "showMap", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        //if segue.identifier == "showMap"{
        let vc = segue.destination as? MapDetailViewController
        if locationLatitude != nil && locationLongitude != nil && locationTitle != nil{
            vc?.locationLatitude = locationLatitude
            vc?.locationLongitude = locationLongitude
            vc?.locationTitle = locationTitle
            // }
        }
    }
    
    func touchMapGoPage(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(showMaps))
        mapView?.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func showMap(){
        
        if locationLatitude != nil && locationLongitude != nil && locationTitle != nil{
            
            let nycAnnotation = MKPointAnnotation();
            nycAnnotation.coordinate = CLLocationCoordinate2D(latitude: locationLatitude!, longitude: locationLongitude!);
            nycAnnotation.title = locationTitle!;
            self.annotations.append(nycAnnotation);
            //Do the rest cities here
            
            self.mapView?.addAnnotations(self.annotations);
            
            
            let overlayCoords = [
                CLLocationCoordinate2D(latitude: locationLatitude!, longitude: locationLongitude!),
                
                ]
            let overlay = MKPolygon(coordinates: overlayCoords, count: 1);
            let span = MKCoordinateSpan(latitudeDelta: 0.6, longitudeDelta: 0.6);
            let coord = CLLocationCoordinate2D(latitude: locationLatitude!, longitude: locationLongitude!);
            let region = MKCoordinateRegion(center: coord, span: span)
            self.mapView?.delegate = self;
            self.mapView?.setRegion(region, animated: false);
            self.mapView?.addOverlay(overlay);
        }
    }
    
    @IBAction func checkLocation(_ sender: AnyObject){
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = locationTF.text
        request.region = (mapView?.region)!
        
        let search = MKLocalSearch(request: request)
        
        search.start{(response, error) in
            guard error == nil else{
                return
            }
            
            guard response != nil else{
                return
            }
            
            for item in (response?.mapItems)!{
                //self.mapView?.addAnnotation(item.placemark)
                self.locationLatitude = item.placemark.coordinate.latitude
                self.locationLongitude = item.placemark.coordinate.longitude
                self.locationTitle = item.name
            }
            
        }
        
        showMap()
        
    }
    //map end////////////
    
    let record_manager = RecordManager()
    @IBAction func recordStart(sender: UILongPressGestureRecognizer) {
        
        
        if sender.state == .began {
            record_manager.beginRecord()
        }
        
        if sender.state == .ended {
            record_manager.stopRecord()
            haverecord = 1
            audiopath = record_manager.getPath(haverecord: haverecord)
        }
    }
    
    @IBOutlet weak var PlayAudioButton: UIButton!
    
    
    @IBAction func PlayAudio(_ sender: Any) {
        record_manager.play()
    }
    
    
    
    @IBAction func searchFood(sender: AnyObject) {
        if (foodName.text == "") {
            let searchAlertController = UIAlertController(title: "Wrong Search!", message: "You should input the name food", preferredStyle: .alert)
            
        } else {
            let getFoodData = GetFoodData()
            foodArray = getFoodData.getName(foodName: foodName.text!)
            valueArray = getFoodData.getCalorie(foodName: foodName.text!)
            
            
            self.name1.text = foodArray[0]
            self.name2.text = foodArray[1]
            self.name3.text = foodArray[2]
            self.name4.text = foodArray[3]
            self.name5.text = foodArray[4]
            
            self.cal1.text = valueArray[0]
            self.cal2.text = valueArray[1]
            self.cal3.text = valueArray[2]
            self.cal4.text = valueArray[3]
            self.cal5.text = valueArray[4]
        }
        
    }
    
    @IBAction func cancel(sender: AnyObject) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func save(sender: AnyObject) {

        if foodName.text != "" && date.text != "" && calorie.text != ""{
        if let context = self.managedObjectContext {
            if let record = theRecord {
                record.foodname = self.foodName.text
                record.calorie = self.calorie.text
                record.date = self.date.text
                record.audioPath = self.audiopath
                record.remark = self.remark.text
                record.belonguser = UserDefaults.standard.string(forKey: "userName")
                
                if let foodImage = foodPhoto.image {
                    if let imageData = foodImage.pngData() {
                        record.image = NSData(data: imageData) as Data

                    }
                }
            } else if let newRecord = NSEntityDescription.insertNewObject(forEntityName: "Record", into: context) as? Record {
                newRecord.foodname = self.foodName.text
                newRecord.calorie = self.calorie.text
                newRecord.date = self.date.text
                newRecord.audioPath = self.audiopath
                newRecord.remark = self.remark.text
                newRecord.belonguser = UserDefaults.standard.string(forKey: "userName")
                
                if let foodImage = foodPhoto.image {
                    if let imageData = foodImage.pngData() {
                        newRecord.image = NSData(data: imageData) as Data
                    }
                }
            }
            do {
                try context.save();
            } catch {
                print("failed saving");

            }
        }
        self.dismiss(animated: true, completion: nil);

        }

    }
    
    @IBAction func dateTextFieldEditing(sender: UITextField) {
        
        let datePickerView: UIDatePicker = UIDatePicker()
        
        datePickerView.datePickerMode = UIDatePicker.Mode.date
        
        
        sender.inputView = datePickerView
        
        datePickerView.addTarget(self, action: #selector(AddFoodViewController.datePickerValueChanged), for: UIControl.Event.valueChanged)
        
    }
    
    
    @objc func datePickerValueChanged(sender: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "d MMM yyyy"
//        dateFormatter.dateStyle = DateFormatter.Style.medium
//
//
//        dateFormatter.timeStyle = DateFormatter.Style.none
        
        let dateString = dateFormatter.string(from: sender.date)
        date.text = dateString
    }
    
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//
//        let numberOnly = NSCharacterSet(charactersIn:"0123456789").inverted
//        let compSepByCharInSet = string.components(separatedBy: numberOnly)
//        let numberFiltered = compSepByCharInSet.joined(separator: "")
//        return string == numberFiltered
//    }
}

extension AddFoodViewController {
    
    var selectorController: UIAlertController {
        let controller = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        controller.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        controller.addAction(UIAlertAction(title: "Take photo", style: .default) { action in
            self.selectorSourceType(type: .camera)
        })
        controller.addAction(UIAlertAction(title: "Choose photo from gallery", style: .default) { action in
            self.selectorSourceType(type: .photoLibrary)
        })
        return controller
    }
    
    @IBAction func onTapImageView(sender: UITapGestureRecognizer) {
        present(selectorController, animated: true, completion: nil)
    }
    
    func selectorSourceType(type: UIImagePickerController.SourceType) {
        imagePickerController.sourceType = type
        self.present(imagePickerController, animated: true, completion: nil)
    }
}

extension AddFoodViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var imagePickerController: UIImagePickerController {
        get {
            let imagePicket = UIImagePickerController()
            imagePicket.delegate = self
            imagePicket.sourceType = .photoLibrary
            
            return imagePicket
        }
    }
    

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        
        foodPhoto.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        foodPhoto.contentMode = .scaleToFill
        foodPhoto.clipsToBounds = true

        dismiss(animated: true, completion: nil)

    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}
