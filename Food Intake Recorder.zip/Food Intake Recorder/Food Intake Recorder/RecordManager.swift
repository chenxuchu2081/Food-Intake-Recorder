//
//  RecordManager.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//
import Foundation
import AVFoundation

class RecordManager {
    
    var recorder: AVAudioRecorder?
    var player: AVAudioPlayer?
    
    
    

    let file_path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first?.appending("/record.wav")
    
    func beginRecord() {
        
        let session = AVAudioSession.sharedInstance()
        
        
        let dateFormatter : DateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMddHHmmss"
        let date = Date()
        let now = dateFormatter.string(from: date)
        
        do {
            try session.setCategory(.playAndRecord, mode: .default, options: [])
        } catch let err{
            print("Error:\(err.localizedDescription)")
        }
        
        do {
            try session.setActive(true)
        } catch let err {
            print("Error:\(err.localizedDescription)")
        }
        
        let recordSetting: [String: Any] = [AVSampleRateKey: NSNumber(value: 16000),
            AVFormatIDKey: NSNumber(value: kAudioFormatLinearPCM),
            AVLinearPCMBitDepthKey: NSNumber(value: 16),
            AVNumberOfChannelsKey: NSNumber(value: 1),
            AVEncoderAudioQualityKey: NSNumber(value: AVAudioQuality.min.rawValue)
        ];
        
        do {
            let url = URL(fileURLWithPath: file_path!)
            recorder = try AVAudioRecorder(url: url, settings: recordSetting)
            recorder!.prepareToRecord()
            recorder!.record()
            print("Start")
        } catch let err {
            print("Failed:\(err.localizedDescription)")
        }
    }
    
    
    func stopRecord() {
        if let recorder = self.recorder {
            if recorder.isRecording {
                print("Save in \(file_path!)")
            }else {
                print("You didn't start record")
            }
            recorder.stop()
            self.recorder = nil
        }else {
            print("Error")
        }
    }
    
    
    func play() {
        do {
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: file_path!))
            print("Length:\(player!.duration)")
            player!.play()
        } catch let err {
            print("Failed play:\(err.localizedDescription)")
        }
    }
    
    func play(path: String) {
        print(path)
        do {
            player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            
            print("Length:\(player!.duration)")
            player!.play()
        } catch let err {
            print("Failed play:\(err.localizedDescription)")
        }
    }
    
    func getPath(haverecord: Int) -> String {
        var path : String = ""
        if (haverecord == 0) {
            path = ""
        } else if (haverecord == 1) {
            path = file_path!
        }

        return path

    }
}
