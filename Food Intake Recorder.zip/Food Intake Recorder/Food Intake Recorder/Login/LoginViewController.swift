//
//  LoginViewController.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 22/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreData

class LoginViewController: UIViewController,UITextFieldDelegate {
    

    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    
    var account : Users?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.usernameTF.delegate = self
        self.passwordTF.delegate = self
        
        }
    
    
    
    @IBAction func backToLogin(segue : UIStoryboardSegue){
        
    }
    
    
    @IBAction func loginButtonTapped(_ sender: Any) {
        let username = usernameTF.text;
        let password = passwordTF.text;
        

        
//        if(userNameStored == username){
//            if(userPasswordStored == password){
//
//            }
//        }
        
//        if(userNameStored != username || userPasswordStored != password){
//
//            displayMyAlertMessage(userMessage: "Couldn't find your Account");
//
//        }
        
        if let managedObjectContext = self.managedObjectContext {
            let fetchRequest = NSFetchRequest<Users>(entityName: "Users");
            if username!.characters.count > 0 && password!.characters.count > 0{
                let predicate_account = NSPredicate(format: "username == %@ AND password == %@", username!,password!)
                
                fetchRequest.predicate = NSCompoundPredicate(orPredicateWithSubpredicates: [predicate_account])
            }
            do {
                let theRecords = try managedObjectContext.fetch(fetchRequest)
                if theRecords.count == 0 {
                    displayMyAlertMessage(userMessage: "Please enter correct username and password")
                } else {
                    
                    UserDefaults.standard.set(username, forKey: "userName");
                UserDefaults.standard.set(true,forKey:"isUserLoggedIn");
                    UserDefaults.standard.synchronize();
//                    
                    self.dismiss(animated: true, completion: nil);
                    
                    
                }
            } catch {
                print("Error")
            }
        }
        
    }
    
    
    func displayMyAlertMessage(userMessage:String){
        
        var myAlert = UIAlertController(title:"Login Fail",message: userMessage, preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title:"OK" , style: UIAlertAction.Style.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated: true, completion:nil);
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

