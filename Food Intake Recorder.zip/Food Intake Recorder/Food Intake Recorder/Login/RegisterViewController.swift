//
//  RegisterViewController.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 22/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreData

class RegisterViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var usernameTF: UITextField!
    
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var repassword: UITextField!
    
    @IBOutlet weak var ageTF: UITextField!
    
    @IBOutlet weak var weightTF: UITextField!
    
    @IBOutlet weak var heightTF: UITextField!
    
    var thelogin : Users?;
    var account : [Users]?
    
    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.usernameTF.delegate = self
        self.passwordTF.delegate = self
        self.repassword.delegate = self
        self.ageTF.delegate = self
        self.weightTF.delegate = self
        self.heightTF.delegate = self
        
    // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
         super.viewWillAppear(animated)
        if let login = thelogin {
            self.usernameTF.text = login.username!
            self.passwordTF.text = login.password!
            self.ageTF.text = login.age!
            self.weightTF.text = login.weight!
            self.heightTF.text = login.height!

          
        }
    }
    
    @IBAction func RegisterButtonTapped(_ sender: Any) {
        let userName = usernameTF.text;
        let userPassword = passwordTF.text;
        let userRepeatPassword = repassword.text;

        
        //core
        if let context = self.managedObjectContext {
            if let login = thelogin {
                login.username = self.usernameTF.text
                login.password = self.passwordTF.text
                login.age = self.ageTF.text
                login.height = self.heightTF.text
                login.weight = self.weightTF.text
         
            } else if let newlogin = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context) as? Users {
                newlogin.username = self.usernameTF.text
                newlogin.password = self.passwordTF.text
                newlogin.age = self.ageTF.text
                newlogin.weight = self.weightTF.text
                newlogin.height = self.heightTF.text
            
                print(newlogin)
            }
            do {
                try context.save()
                
            } catch {
                print("failed saving");
                
            }
           
        }

//
    
//        do{
//            let results = try contect.fetch(request)
//
//            if results.count > 0{
//
//                for result in results as! [NSManagedObject]{
//                    if (result.value(forKey: "username") as? String) != nil{
//                        usernameArray.append(usernameTF.text!)
//                        try contect.save()
//
//                    }
//                    if (result.value(forKey: "password") as? String) != nil{
//                        passwordArray.append(passwordTF.text!)
//                        try contect.save()
//
//                    }
//
//                }
//                try contect.save()
//
//                print(results)
//
//            }
//        }catch{
//
//        }

       
        
        if((userName?.isEmpty)! || (userPassword?.isEmpty)! || (userRepeatPassword?.isEmpty)!){
            
            displayMyAlertMessage(userMessage: "All fields are required");
            
            return;
        }
        
        if(userPassword != userRepeatPassword){
            
            displayMyAlertMessage(userMessage: "Passwords do not match");
            
            return;
        }
        
        
//        UserDefaults.standard.set(userName,forKey: "userName");
//        UserDefaults.standard.set(userPassword,forKey: "userPassword");
//        UserDefaults.standard.set(ageTF.text, forKey: "userAge");
//        UserDefaults.standard.set(weightTF.text, forKey: "userWeight");
//        UserDefaults.standard.set(heightTF.text, forKey: "userHeight");
//
//        UserDefaults.standard.synchronize();
//
        var myAlert = UIAlertController(title:"Alert",message: "Registeration is suncessful", preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title:"OK" , style: UIAlertAction.Style.default){action in
            self.dismiss(animated: true, completion:nil);
        }
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated:true, completion:nil);
    }
    
    
    func displayMyAlertMessage(userMessage:String){
        
        var myAlert = UIAlertController(title:"Alert",message: userMessage, preferredStyle: UIAlertController.Style.alert);
        
        let okAction = UIAlertAction(title:"OK" , style: UIAlertAction.Style.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated: true, completion:nil);
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
