import UIKit
import CoreData

class PersonalViewController: UITableViewController {
    
    @IBOutlet var usernameLabel: UILabel!
    @IBOutlet var ageLabel: UILabel!
    @IBOutlet var weightLabel: UILabel!
    @IBOutlet var heightLabel: UILabel!
    
    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    
    func reloadInfo() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        request.predicate = NSPredicate(format: "username == %@", UserDefaults.standard.string(forKey: "userName")!)
//        request.returnsObjectsAsFaults = false
        do {
            let result = try managedObjectContext!.fetch(request)
            
            for data in result as! [NSManagedObject] {
                ageLabel.text = data.value(forKey: "age") as? String
                weightLabel.text = (data.value(forKey: "weight") as! String)
                heightLabel.text = (data.value(forKey: "height") as! String)
            }
            
        } catch {
            
            print("Failed")
        }
    }
    
    var theInfor : Users?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        usernameLabel.text = UserDefaults.standard.string(forKey: "userName")
        
        reloadInfo()
    }
    
    
    
    
    
    /*=// MARK: - Navigation
     
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

