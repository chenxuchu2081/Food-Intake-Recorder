//
//  CustomRecordCell.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 26/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//

import UIKit

class CustomRecordCell: UITableViewCell {

    @IBOutlet var foodNameLabel: UILabel!
    @IBOutlet var calorieLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var photoImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
