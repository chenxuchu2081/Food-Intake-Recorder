//
//  RecordViewController.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//

import UIKit
import CoreData

class RecordViewController: UITableViewController,UITextFieldDelegate {
    
    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    var records : [Record]?;
  
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var searchbar : UITextField!
    
    
    @IBAction func search (sender : AnyObject){
        if let text = self.searchbar.text{
            self.ReloadSearch(query: text)
        }
    }
    
    func ReloadSearch(query:String){
        
        if let managedObjectContext = self.managedObjectContext {
            let userNow = UserDefaults.standard.string(forKey: "userName")
            let fetchRequest = NSFetchRequest<Record>(entityName: "Record");
            
            if query.characters.count > 0 {
                let predicate_foodname = NSPredicate(format: "foodname contains[cd] %@ AND belonguser == %@", query, userNow!)
                let predicate_date = NSPredicate(format: "date contains[cd] %@ AND belonguser == %@", query, userNow!)
                
        
                fetchRequest.predicate = NSCompoundPredicate(orPredicateWithSubpredicates: [predicate_foodname,predicate_date])
            } else if query.characters.count == 0 {
                let predicate_username = NSPredicate(format: "belonguser == %@", userNow!)
                
                fetchRequest.predicate = NSCompoundPredicate(orPredicateWithSubpredicates: [predicate_username])
            }
            do {
                let theRecords = try managedObjectContext.fetch(fetchRequest)
                self.records = theRecords
                self.tableView.reloadData()
            } catch {
                
            }
        }
    }
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tableView.rowHeight = 100
        self.searchbar.delegate = self
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if (UserDefaults.standard.string(forKey: "userName") != nil) {
            self.ReloadSearch(query: "")
        }
        
        print(UserDefaults.standard.string(forKey: "userName"))
//        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Record")
//        //request.predicate = NSPredicate(format: "age = %@", "12")
//        request.returnsObjectsAsFaults = false
//        do {
//            let result = try managedObjectContext!.fetch(request)
//            for data in result as! [NSManagedObject] {
//                print(data.value(forKey: "belongUser") as! String)
//            }
//
//        } catch {
//
//            print("Failed")
//        }
        
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let records = self.records {
            return records.count
        }
        return 0
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecordCell", for: indexPath) as! CustomRecordCell
        
//        let food = (searchController.isActive) ? searchResult[indexPath.row] : foods[indexPath.row]

        if let record = self.records?[indexPath.row] {
            if (record.image != nil) {
                cell.photoImage.image = UIImage(data: record.image as! Data)
                cell.photoImage.layer.masksToBounds = true
                cell.photoImage.layer.cornerRadius = 39
            }
            
            cell.foodNameLabel.text = record.foodname!
            cell.calorieLabel.text = "\(record.calorie!)cals"
            cell.timeLabel.text = record.date
      
        }
        return cell
    }
    
    
    
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let shareAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Share", handler: { (action, indexPath) -> Void in
            
            let defaultText = "FoodName: " + (self.records?[indexPath.row].foodname!)! + "\nCalorie :" + (self.records?[indexPath.row].calorie!)! + "\nRemark: " + (self.records?[indexPath.row].remark!)! + "\nDate: " + (self.records?[indexPath.row].date!)!
            
            let activityController = UIActivityViewController(activityItems: [defaultText], applicationActivities: nil)
            self.present(activityController, animated: true, completion: nil)
        
//            if let imageToShare = UIImage(data: self.records?[indexPath.row].foodImage as! Data) {
//                let activityController = UIActivityViewController(activityItems: [defaultText, imageToShare], applicationActivities: nil)
//                self.present(activityController, animated: true, completion: nil)
//            }
        })
        
        // Delete button
        let deleteAction = UITableViewRowAction(style: UITableViewRowAction.Style.default, title: "Delete",handler: { (action, indexPath) -> Void in

            if let appDelegate = (UIApplication.shared.delegate as? AppDelegate){
                let context = appDelegate.persistentContainer.viewContext
                let foodToDelete = self.records?.remove(at: indexPath.row)
                context.delete(foodToDelete!)

                appDelegate.saveContext()
            }
            // Delete the row from the data source
            // self.foods.remove(at: indexPath.row)


            self.tableView.deleteRows(at: [indexPath], with: .fade)
        })
        
        
        
        shareAction.backgroundColor = UIColor(red: 49.0/255.0, green: 170.0/255.0, blue: 95.0/255.0, alpha: 1.0)
        deleteAction.backgroundColor = UIColor(red: 180.0/255.0, green: 180.0/255.0, blue: 180.0/255.0, alpha: 1.0)
        
        return [deleteAction, shareAction]
    }
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detail" {
            if let navVC = segue.destination as? FoodDetailViewController {
                    if let indexPath = tableView.indexPathForSelectedRow {
                        if let devicess = self.records {
                            navVC.foodrecord = devicess[indexPath.row]
                        }
                    }
                
            }
        }
    }
  
    
    override func viewDidAppear(_ animated: Bool) {
        
        let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn");
        
        if(!isUserLoggedIn){
            
            self.performSegue(withIdentifier: "loginView",sender: self);
        }
    }
    
    @IBAction func logOut(segue: UIStoryboardSegue){
        UserDefaults.standard.set(false, forKey: "isUserLoggedIn")
        UserDefaults.standard.set("", forKey: "userName")
        UserDefaults.standard.synchronize()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
