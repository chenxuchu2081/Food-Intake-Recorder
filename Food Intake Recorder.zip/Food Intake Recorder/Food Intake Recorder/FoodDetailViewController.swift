//
//  FoodDetailViewController.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 29/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//

import UIKit
import CoreData

class FoodDetailViewController: UIViewController {

    
    @IBOutlet weak var foodname: UILabel!
    @IBOutlet weak var calorie: UILabel!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var remark: UILabel!
    @IBOutlet weak var foodPhoto: UIImageView!
    
    @IBOutlet weak var playrecord: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  
    
    var foodrecord : Record?

    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)

        if let food = foodrecord{
            self.foodname.text = food.foodname
            self.calorie.text = "\(food.calorie!) cals"
            self.remark.text = food.remark
            self.date.text = food.date
            if (food.image != nil) {
                self.foodPhoto.image = UIImage(data: food.image as! Data)
            }
        }
    }
    
    let record_manager = RecordManager()
    
    
    @IBAction func play(_ sender: Any) {
        var path = ""
        if let food = foodrecord {
            path = food.audioPath!
            if (path != "") {
                record_manager.play(path: path)
            }
            
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
