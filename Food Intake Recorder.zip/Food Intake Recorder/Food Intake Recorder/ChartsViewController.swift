//
//  ChartsViewController.swift
//  Food Intake Recorder
//
//  Created by Austen on 2/1/2019.
//  Copyright © 2019年 CHEN Xuchu. All rights reserved.
//

import UIKit
import Charts
import CoreData

class ChartsViewController: UIViewController {

    var managedObjectContext : NSManagedObjectContext? {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            return appDelegate.persistentContainer.viewContext
        }
        return nil;
    }
    var records : [Record]?;
    
    var age: Double = 0
    var weight: Double = 0
    var height: Double = 0
    var calorieNeed: Int = 0
    
    @IBOutlet weak var lineChartView : LineChartView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        lineChartView.rightAxis.removeAllLimitLines()
        var date : [String] = [String]()
        var calorie : [Double] = [Double]()
        var nonRepeat = [String:Array<Double>]()

        if let managedObjectContext = self.managedObjectContext {
            let fetchRequest = NSFetchRequest<Record>(entityName: "Record");
            fetchRequest.predicate = NSPredicate(format: "belonguser == %@", UserDefaults.standard.string(forKey: "userName")!)
            do {
                let theRecords = try managedObjectContext.fetch(fetchRequest)
                self.records = theRecords
            } catch {
            }
        }
        
        calCalorieNeed()
        
        
        
        for i in 0..<records!.count{
            if nonRepeat.keys.contains((records?[i].date)!){
                if let calories = records![i].calorie {
                    let cal = Double(calories)
                    nonRepeat[(records?[i].date)!]?.append(cal!)
                }
            } else {
                if let calories = records![i].calorie {
                    let cal = Double(calories)
                    nonRepeat[(records?[i].date)!] = [cal] as? [Double]
                }
            }

        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "d MMM yyyy"
        
        let sortdate = nonRepeat
            .map{(dateFormatter.date(from: $0.key)!, [$0.key:$0.value])}
            .sorted{$0.0 < $1.0}
            .map{$1}

        for i in 0..<sortdate.count{
            let nonRepeatDate = sortdate[i].keys.first!
            date.append(nonRepeatDate)
            calorie.append((sortdate[i][nonRepeatDate]!.reduce(0, +)))
        }

        
        if !date.isEmpty && !calorie.isEmpty {
            let line = ChartLimitLine(limit: Double(calorieNeed), label: "Standard")
            line.lineWidth = 5.0
            line.lineColor  = UIColor.black.withAlphaComponent(0.5)
            line.valueTextColor = UIColor.red.withAlphaComponent(0.5)
            line.lineDashLengths = [10,10]
            lineChartView.rightAxis.addLimitLine(line)
            lineChartView.dragEnabled = true
            lineChartView.setVisibleXRangeMaximum(2)
            let axisy = lineChartView.rightAxis
            axisy.axisMinimum = 0
            let yaxis = lineChartView.leftAxis
            yaxis.axisMinimum = 0
            yaxis.drawGridLinesEnabled = false
            let xaxis = lineChartView.xAxis
            xaxis.drawGridLinesEnabled = false
            xaxis.granularityEnabled = true
            xaxis.granularity = 1
            setChart(dataPoints: date, values: calorie)
        }else{
            lineChartView.data = nil
        }
        
        lineChartView.noDataText = "Please enter records first"
        
    }
    func setChart(dataPoints: [String], values: [Double]) {
        
        var dataEntries: [ChartDataEntry] = []
        
        for i in 0..<dataPoints.count {
            let dataEntry = ChartDataEntry(x: Double(i), y: values[i])
            dataEntries.append(dataEntry)
        }
        let lineChartDataSet = LineChartDataSet(values: dataEntries, label: "Calorie")
        let lineChartData = LineChartData(dataSet: lineChartDataSet)
        
        lineChartView.xAxis.labelPosition = .bottom
        lineChartView.data = lineChartData
        lineChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: dataPoints)
        
    }
    
    func calCalorieNeed() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        request.predicate = NSPredicate(format: "username == %@", UserDefaults.standard.string(forKey: "userName")!)
//        request.returnsObjectsAsFaults = false
        do {
            let result = try managedObjectContext!.fetch(request)
            
            for data in result as! [NSManagedObject] {
                age = Double(data.value(forKey: "age") as! String)!
                weight = Double(data.value(forKey: "weight") as! String)!
                height = Double(data.value(forKey: "height") as! String)!
            }
            
        } catch {
            
            print("Failed")
        }
        
        calorieNeed = Int(655 + (9.6 * weight) + (1.8 * height) - (4.7 * age))
    }
    
}
