//
//  Users+CoreDataClass.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 28/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Users)
public class Users: NSManagedObject {

}
