//
//  Record+CoreDataProperties.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//
//

import Foundation
import CoreData


extension Record {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Record> {
        return NSFetchRequest<Record>(entityName: "Record")
    }

    @NSManaged public var foodname: String?
    @NSManaged public var calorie: String?
    @NSManaged public var remark: String?
    @NSManaged public var audioPath: String?
    @NSManaged public var date: String?
    @NSManaged public var image: Data?
    @NSManaged public var belonguser: String?
}
