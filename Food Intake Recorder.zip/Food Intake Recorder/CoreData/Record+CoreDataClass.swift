//
//  Record+CoreDataClass.swift
//  CalorieManagement
//
//  Created by Yiu Lik Ngai on 25/12/2018.
//  Copyright © 2018年 Yiu Lik Ngai. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Record)
public class Record: NSManagedObject {

}
