//
//  Users+CoreDataProperties.swift
//  Food Intake Recorder
//
//  Created by DennisChiu on 28/12/2018.
//  Copyright © 2018年 CHEN Xuchu. All rights reserved.
//
//

import Foundation
import CoreData


extension Users {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Users> {
        return NSFetchRequest<Users>(entityName: "Users")
    }

    @NSManaged public var password: String?
    @NSManaged public var username: String?
    @NSManaged public var age: String?
    @NSManaged public var weight: String?
    @NSManaged public var height: String?
    @NSManaged public var sex: String?



}
